<?php
// membuat koneksi

$host = "localhost";
$user = "root"; // ganti dengan username database Anda
$password = ""; // ganti dengan password database Anda
$dbname = "db_inventory";

$conn = new mysqli($host, $user, $password, $dbname);

?>